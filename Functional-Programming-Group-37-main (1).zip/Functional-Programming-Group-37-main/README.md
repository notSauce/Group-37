# Crime
Create a application using haskell and its datatypes whcich has has the ability to retreive crime data
from offficial and goverment websites to where it uses the said data to matipiulate the data after it 
has been stored in a database.

Source: (Website Link)


1. Go to destination folder 
2. Run stack build 
3. Run stack exec crime-exe
4. Select the optiion that the type of crime you are interested in
5. Then select the type of display of data (Database or Graph or Stat)
-- Data gets downloaded and inserest appropriately 

Options:

If selected:

Database - the data gets downloaded and inserted into a database
Graph - the option to see the type of graph that you want (High, Low e.g.)
Stat - the avg crime rate, the details and then the choice to choose the data
