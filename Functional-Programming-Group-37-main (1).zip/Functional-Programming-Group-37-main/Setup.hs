
{-  
                                      Distribution.Simple 

This is the command line front-end to the 'Simple' build system. When given the parsed commandline args and package information, 
has the ability to perform basic commands like register, configure, instal, build, etc.
-}

import Distribution.Simple
main = defaultMain
