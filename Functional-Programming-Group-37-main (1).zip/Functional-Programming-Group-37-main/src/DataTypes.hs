module DataTypes

[-- Here are just holders and possible examples:
( CrimetoCompare (CrimetoCompare),
Crime (Crime)

) where 

data CrimetoCompare = CrimetoCompare {
   date :: String,
   total :: Double,
   percentage :: Float, 
   types :: string,
} 
